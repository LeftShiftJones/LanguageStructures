# Taskr
## Converting Plain Text to Productivity

**Authors:** Ryan Jones and David Fletcher

## Important Info

* run the web server with `launch.py`
* compile and run Taskr with `ANTLR`